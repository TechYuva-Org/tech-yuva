# Authentication Specification (AUTHENTICATION.md)

## Overview
- **Current Architecture**: Developer-focused, Header-Mocking Identity Model (using `x-user-email` requests headers)
- **Goal**: Allow effortless platform evaluation in the sandboxed preview environment while maintaining clear pathways for enterprise security migration.
- **Author**: Lakshay Soni (Lead Architect & Founder)
- **Last Updated**: July 2026
- **Status**: Security & Access Specs (v0.9)

---

## 1. Current Authentication Flow

The current pre-production setup uses a high-speed, local **Identity Switcher** designed to simplify developer testing. Users do not need to authenticate via Google OAuth or fill passwords to test distinct user journeys:

```
                  +-----------------------------------+
                  |      Header Identity Switcher     |
                  +-----------------------------------+
                                    |
          +-------------------------+-------------------------+
          |                         |                         |
          v                         v                         v
   [ROLE: VISITOR]           [ROLE: MEMBER]            [ROLE: ADMIN]
   No email passed           Registered email          dakshchaudhary2668@gmail.com
   Read events, register     Download certificates,    Manage CMS panels,
   for hackathons.           check member details.     access terminal, seed database.
```

### Authorization Enforcement Middleware
All critical database write operations in `server.ts` use the `requireAdmin` helper:
```typescript
export async function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const userEmail = req.headers["x-user-email"] as string;
  if (!userEmail) {
    return res.status(401).json({ error: "Authentication required. 'x-user-email' header is missing." });
  }
  
  // Strict admin email check matching Lakshay's design identity
  if (userEmail.trim().toLowerCase() !== "dakshchaudhary2668@gmail.com") {
    return res.status(403).json({ error: "Forbidden. Admin authorization required." });
  }
  
  next();
}
```

---

## 2. Session Persistence Strategy

To preserve session states across container restarts, browser reloads, and offline drops:
1. **Local Storage Synchronization**:
   - The user’s selected role and email are serialized and saved under `localStorage.setItem("techyuva_user", ...)` on the client.
   - Upon initial hydration, `main.tsx` loads the stringified object, instantiating the TanStack Query cache headers context.
2. **Dynamic Header Injectors**:
   - The custom `cmsFetch` utility dynamically pulls the current cached state:
     ```typescript
     const headers = {
       "Content-Type": "application/json",
       "x-user-email": currentUser?.email || ""
     };
     ```

---

## 3. Production Authentication Roadmap (Firebase Auth Integration)

For staging and public production deployments, the platform will migrate to Firebase Authentication and Google OAuth. This replaces mock headers with signed JSON Web Tokens (JWT).

```mermaid
sequenceDiagram
    participant User as Developer Browser
    participant Firebase as Firebase Auth Service
    participant Backend as Express API (Cloud Run)
    participant DB as PostgreSQL (Cloud SQL)

    User->>Firebase: signInWithPopup(GoogleAuthProvider)
    Firebase-->>User: Return Signed Google JWT IdToken
    User->>Backend: GET /api/member/profile (Header Authorization: Bearer <JWT>)
    Backend->>Firebase: Verify JWT signature (adminSDK.verifyIdToken)
    Firebase-->>Backend: Token Valid (Email: user@example.com)
    Backend->>DB: SELECT * FROM users WHERE email = 'user@example.com'
    DB-->>Backend: Return User (Role: Member)
    Backend-->>User: Return 200 OK (Authenticated Member Payload)
```

### Implementation Steps
1. **Secure Admin SDK Initialization**:
   - Load the Firebase service account credential via server-side environment variables `FIREBASE_SERVICE_ACCOUNT`.
2. **Token Extraction Middleware**:
   ```typescript
   import admin from "firebase-admin";

   async function authenticateFirebaseToken(req: Request, res: Response, next: NextFunction) {
     const authHeader = req.headers.authorization;
     if (!authHeader || !authHeader.startsWith("Bearer ")) {
       return res.status(401).json({ error: "Missing bearer token" });
     }
     const token = authHeader.split(" ")[1];
     try {
       const decodedToken = await admin.auth().verifyIdToken(token);
       req.user = decodedToken; // contains email, user_id, picture
       next();
     } catch (err) {
       return res.status(403).json({ error: "Invalid Firebase Authorization Token" });
     }
   }
   ```
3. **Database Role Mapping**:
   - Instead of checking hardcoded emails, verify role entries securely within the database `users.role` field.
